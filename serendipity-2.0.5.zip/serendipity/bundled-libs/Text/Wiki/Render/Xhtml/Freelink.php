<?php

require_once 'Text/Wiki/Render/Xhtml/Wikilink.php';

class Text_Wiki_Render_Xhtml_Freelink extends Text_Wiki_Render_Xhtml_Wikilink {
    // renders identically to wikilinks, only the parsing is different :-)
}

?>