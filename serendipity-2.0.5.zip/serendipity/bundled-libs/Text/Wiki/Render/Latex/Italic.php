<?php

class Text_Wiki_Render_Latex_Italic extends Text_Wiki_Render_Latex_Emphasis {
}
?>