<?php

class Text_Wiki_Render_Latex_Bold extends Text_Wiki_Render_Latex_Strong {}
?>